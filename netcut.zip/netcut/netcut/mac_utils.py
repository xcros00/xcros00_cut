import random
import re
from typing import Optional


def get_random_mac(oui_prefix: str = "CC:46:D6") -> str:
    """
    Generate a fake random MAC address.
    By default, uses the Cisco OUI prefix CC:46:D6 matching the original C++ tool.
    """
    suffix = ":".join(f"{random.randint(0, 255):02X}" for _ in range(3))
    return f"{oui_prefix}:{suffix}"


def format_mac(mac: str) -> str:
    """Format MAC address to standard uppercase colon-separated format."""
    cleaned = re.sub(r"[^0-9A-Fa-f]", "", mac)
    if len(cleaned) == 12:
        return ":".join(cleaned[i:i + 2].upper() for i in range(0, 12, 2))
    return mac.upper()


def is_valid_mac(mac: str) -> bool:
    """Check if the string is a valid MAC address format."""
    pattern = r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"
    return bool(re.match(pattern, mac))
