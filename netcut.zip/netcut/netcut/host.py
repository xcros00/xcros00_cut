import ipaddress
from enum import Enum
from typing import Optional, Dict, Any


class Status(Enum):
    NORMAL = "NORMAL"
    CUT = "CUT"


class Host:
    def __init__(self, ip_address: str, mac_address: str, vendor: str = "", hostname: str = ""):
        self.ip_address: str = ip_address
        self.mac_address: str = mac_address.upper()
        self.vendor: str = vendor
        self.hostname: str = hostname
        self.status: Status = Status.NORMAL

    @property
    def ip_int(self) -> int:
        try:
            return int(ipaddress.IPv4Address(self.ip_address))
        except ValueError:
            return 0

    def is_cut(self) -> bool:
        return self.status == Status.CUT

    def set_status(self, status: Status) -> None:
        self.status = status

    def set_mac_address(self, mac_address: str) -> None:
        self.mac_address = mac_address.upper()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ip": self.ip_address,
            "mac": self.mac_address,
            "vendor": self.vendor,
            "hostname": self.hostname,
            "is_cut": self.is_cut(),
            "status": self.status.value,
        }

    def __lt__(self, other: "Host") -> bool:
        return self.ip_int < other.ip_int

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Host):
            return self.ip_address == other.ip_address
        return False

    def __hash__(self) -> int:
        return hash(self.ip_address)

    def __repr__(self) -> str:
        return f"<Host {self.ip_address} ({self.mac_address}) [{self.status.value}]>"
