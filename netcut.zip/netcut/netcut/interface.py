import ipaddress
from typing import Optional


class Interface:
    def __init__(self, name: str = "", ip: str = "", netmask: str = "255.255.255.0", mac: str = ""):
        self.name = name
        self.ip = ip
        self.netmask = netmask
        self.mac = mac.upper() if mac else ""
        self._network: Optional[ipaddress.IPv4Network] = None

        if self.ip and self.netmask:
            try:
                self._network = ipaddress.IPv4Network(f"{self.ip}/{self.netmask}", strict=False)
            except ValueError:
                self._network = None

    @property
    def network(self) -> Optional[ipaddress.IPv4Network]:
        return self._network

    def is_same_subnet(self, target_ip: str) -> bool:
        if not self._network:
            return False
        try:
            return ipaddress.IPv4Address(target_ip) in self._network
        except ValueError:
            return False

    def __repr__(self) -> str:
        return f"<Interface name={self.name} ip={self.ip} netmask={self.netmask}>"
