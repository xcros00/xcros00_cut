import sys
import socket
import struct
import platform
import ipaddress
import subprocess
import concurrent.futures
from typing import List, Dict, Optional, Tuple

try:
    import psutil
except ImportError:
    psutil = None

try:
    import ctypes
    if sys.platform == "win32":
        windll_iphlpapi = ctypes.windll.iphlpapi
    else:
        windll_iphlpapi = None
except Exception:
    windll_iphlpapi = None

try:
    from scapy.all import ARP, Ether, srp, conf
    SCAPY_AVAILABLE = True
except Exception:
    SCAPY_AVAILABLE = False
    conf = None

from .host import Host
from .interface import Interface
from .mac_utils import format_mac


class NetworkScanner:
    """
    Scans local networks for connected active hosts.
    Provides fast multi-threaded Windows SendARP scanning, Scapy L2 ARP broadcast,
    and ARP cache parsing fallback.
    """

    def __init__(self):
        self.interfaces: List[Interface] = []
        self.gateway_ip: Optional[str] = None
        self.gateway_mac: Optional[str] = None

    def get_interfaces(self) -> List[Interface]:
        """Detects active network interfaces with valid IPv4 addresses."""
        detected: List[Interface] = []

        if psutil:
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()

            for iface_name, iface_addrs in addrs.items():
                if iface_name in stats and not stats[iface_name].isup:
                    continue

                ipv4 = None
                netmask = "255.255.255.0"
                mac = ""

                for addr in iface_addrs:
                    if addr.family.name in ("AF_LINK", "AF_PACKET"):
                        mac = addr.address
                    elif addr.family.name == "AF_INET":
                        if addr.address.startswith("127.") or addr.address.startswith("169.254."):
                            continue
                        ipv4 = addr.address
                        if addr.netmask:
                            netmask = addr.netmask

                if ipv4:
                    detected.append(Interface(name=iface_name, ip=ipv4, netmask=netmask, mac=mac))

        self.interfaces = detected
        return self.interfaces

    def get_default_interface(self) -> Optional[Interface]:
        """Finds the primary interface connected to the default gateway."""
        if not self.interfaces:
            self.get_interfaces()

        if SCAPY_AVAILABLE and conf and hasattr(conf, "route"):
            try:
                route_res = conf.route.route("0.0.0.0")
                if route_res and len(route_res) >= 3:
                    gw_ip = route_res[2]
                    self.gateway_ip = gw_ip
                    local_ip = route_res[1]
                    for iface in self.interfaces:
                        if iface.ip == local_ip:
                            return iface
            except Exception:
                pass

        if self.interfaces:
            return self.interfaces[0]
        return None

    def get_interface_by_ip(self, ip: str) -> Optional[Interface]:
        """Returns the interface on the same subnet as the given IP."""
        for iface in self.interfaces:
            if iface.is_same_subnet(ip):
                return iface
        return None

    def _resolve_mac_windows_sendarp(self, ip_str: str) -> Optional[str]:
        """Resolves MAC address using Windows native SendARP API (fast & no WinPcap needed)."""
        if not windll_iphlpapi:
            return None
        try:
            dest_ip = struct.unpack("<I", socket.inet_aton(ip_str))[0]
            mac_buf = (ctypes.c_byte * 6)()
            mac_len = ctypes.c_ulong(6)
            res = windll_iphlpapi.SendARP(dest_ip, 0, ctypes.byref(mac_buf), ctypes.byref(mac_len))
            if res == 0:
                mac = ":".join(f"{b & 0xff:02X}" for b in mac_buf)
                return mac
        except Exception:
            pass
        return None

    def _scan_subnet_sendarp(self, interface: Interface, max_threads: int = 80) -> List[Host]:
        """Ultra-fast multi-threaded subnet scan using Windows SendARP without blocking DNS lookups."""
        hosts: List[Host] = []
        if not interface.network:
            return hosts

        candidate_ips = [
            str(ip) for ip in interface.network.hosts()
            if str(ip) != interface.ip
        ]

        def check_host(ip: str) -> Optional[Host]:
            mac = self._resolve_mac_windows_sendarp(ip)
            if mac and mac != "00:00:00:00:00:00":
                return Host(ip_address=ip, mac_address=mac)
            return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
            results = executor.map(check_host, candidate_ips)
            for h in results:
                if h:
                    hosts.append(h)

        return hosts

    def _scan_subnet_scapy(self, interface: Interface) -> List[Host]:
        """Scans subnet using Scapy Layer 2 ARP broadcast."""
        if not SCAPY_AVAILABLE or not interface.network:
            return []

        hosts: List[Host] = []
        subnet_cidr = str(interface.network)

        try:
            arp_req = Ether(dst="ff:ff:ff:ff:ff:ff") / ARP(pdst=subnet_cidr)
            ans, _ = srp(arp_req, timeout=1.5, verbose=False, iface=interface.name)

            for sent, received in ans:
                if received.psrc != interface.ip:
                    hosts.append(Host(
                        ip_address=received.psrc,
                        mac_address=received.hwsrc
                    ))
        except Exception:
            return []

        return hosts

    def _scan_arp_cache(self, interface: Interface) -> List[Host]:
        """Fallback to reading OS ARP cache."""
        hosts: List[Host] = []
        try:
            output = subprocess.check_output(["arp", "-a"], universal_newlines=True, stderr=subprocess.DEVNULL)
            for line in output.splitlines():
                parts = line.strip().split()
                if len(parts) >= 2:
                    ip = parts[0]
                    mac = parts[1]
                    if interface.is_same_subnet(ip) and ip != interface.ip:
                        formatted = format_mac(mac)
                        if len(formatted.split(":")) == 6 and not formatted.startswith("FF:FF"):
                            hosts.append(Host(ip_address=ip, mac_address=formatted))
        except Exception:
            pass
        return hosts

    def scan_networks(self, interface: Optional[Interface] = None) -> List[Host]:
        """Scans network for active hosts."""
        if not self.interfaces:
            self.get_interfaces()

        target_iface = interface or self.get_default_interface()
        if not target_iface:
            return []

        discovered: Dict[str, Host] = {}

        # 1. On Windows, SendARP is fastest and requires zero third-party drivers
        if sys.platform == "win32" and windll_iphlpapi:
            win_hosts = self._scan_subnet_sendarp(target_iface)
            for h in win_hosts:
                discovered[h.ip_address] = h

        # 2. Try Scapy if hosts not found or on Linux
        if not discovered and SCAPY_AVAILABLE:
            scapy_hosts = self._scan_subnet_scapy(target_iface)
            for h in scapy_hosts:
                discovered[h.ip_address] = h

        # 3. Augment with ARP cache
        arp_hosts = self._scan_arp_cache(target_iface)
        for h in arp_hosts:
            if h.ip_address not in discovered:
                discovered[h.ip_address] = h

        # Detect gateway MAC if gateway_ip is known
        if self.gateway_ip and self.gateway_ip in discovered:
            self.gateway_mac = discovered[self.gateway_ip].mac_address

        return sorted(discovered.values())
