#!/usr/bin/env python3
"""
NetCut Web Dashboard
A modern Flask-based web interface for NetCut.
"""

import os
import sys
import threading
import atexit
from flask import Flask, render_template, jsonify, request, send_file
from netcut.controller import NetCutController

app = Flask(__name__)
controller = NetCutController(attack_interval_s=2.0)
controller.initialize()

is_scanning = False
scan_lock = threading.Lock()

# Ensure hosts are recovered on server shutdown
atexit.register(controller.recover_all_hosts)


def _background_scan():
    global is_scanning
    with scan_lock:
        if is_scanning:
            return
        is_scanning = True
    try:
        controller.scan_targets()
    finally:
        with scan_lock:
            is_scanning = False


# Start initial network scan in background immediately
threading.Thread(target=_background_scan, daemon=True).start()


@app.route("/")
def index():
    """Renders the main dashboard."""
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    """Returns general network & attack status without blocking."""
    l2_ready, l2_msg = controller.get_l2_status()
    with controller._lock:
        total_hosts = len(controller.hosts)
        cut_hosts = sum(1 for h in controller.hosts if h.is_cut())

    installer_path = os.path.join(os.path.dirname(__file__), "npcap-installer.exe")
    has_installer = os.path.exists(installer_path)

    return jsonify({
        "interface": controller.interface.name if controller.interface else "N/A",
        "local_ip": controller.interface.ip if controller.interface else "N/A",
        "netmask": controller.interface.netmask if controller.interface else "N/A",
        "gateway_ip": controller.scanner.gateway_ip or "Auto",
        "gateway_mac": controller.scanner.gateway_mac or "N/A",
        "total_hosts": total_hosts,
        "cut_hosts": cut_hosts,
        "is_scanning": is_scanning,
        "l2_ready": l2_ready,
        "l2_message": l2_msg,
        "has_installer": has_installer,
        "os": sys.platform
    })


@app.route("/api/hosts")
def api_hosts():
    """Returns list of currently discovered hosts."""
    with controller._lock:
        hosts_data = [h.to_dict() for h in controller.hosts]
    return jsonify({
        "hosts": hosts_data,
        "gateway_ip": controller.scanner.gateway_ip,
        "is_scanning": is_scanning
    })


@app.route("/api/scan", methods=["POST"])
def api_scan():
    """Triggers an active network scan and returns current status."""
    global is_scanning
    if not is_scanning:
        threading.Thread(target=_background_scan, daemon=True).start()
    return jsonify({
        "status": "scanning",
        "message": "Scan started in background"
    })


@app.route("/api/toggle/<path:ip>", methods=["POST"])
def api_toggle(ip):
    """Toggles cut/recover state for a specific IP."""
    target = controller.get_host_by_ip(ip)
    if not target:
        return jsonify({"status": "error", "message": f"Host {ip} tidak ditemukan"}), 404

    if target.is_cut():
        controller.recover(target)
        return jsonify({
            "status": "success",
            "host": target.to_dict(),
            "action": "RECOVERED"
        })
    else:
        ok, msg = controller.attack(target)
        if not ok:
            return jsonify({
                "status": "error",
                "message": msg,
                "needs_npcap": not controller.get_l2_status()[0]
            }), 400

        return jsonify({
            "status": "success",
            "host": target.to_dict(),
            "action": "CUT"
        })


@app.route("/api/recover-all", methods=["POST"])
def api_recover_all():
    """Restores connectivity for all cut hosts."""
    controller.recover_all_hosts()
    return jsonify({"status": "success", "message": "Semua koneksi host dipulihkan"})


@app.route("/api/download-npcap")
def api_download_npcap():
    """Directly serves npcap-installer.exe so the user's browser can download and run it."""
    installer_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "npcap-installer.exe"))
    if os.path.exists(installer_path):
        return send_file(installer_path, as_attachment=True, download_name="npcap-installer.exe")
    return jsonify({"status": "error", "message": "npcap-installer.exe tidak ditemukan."}), 404


@app.route("/api/install-npcap", methods=["POST"])
def api_install_npcap():
    """Launches the downloaded Npcap installer for Windows."""
    installer_path = os.path.join(os.path.dirname(__file__), "npcap-installer.exe")
    if os.path.exists(installer_path):
        try:
            if sys.platform == "win32":
                os.startfile(installer_path)
            return jsonify({
                "status": "success",
                "message": "Installer Npcap telah dibuka di Windows.",
                "download_url": "/api/download-npcap",
                "file_path": installer_path
            })
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
    return jsonify({"status": "error", "message": "npcap-installer.exe tidak ditemukan."}), 404


if __name__ == "__main__":
    print("\n[+] Starting NetCut Web Dashboard on http://127.0.0.1:5000 ...")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
